# Compose works with the default R8 rules; nothing extra needed.
