package com.halo.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

enum class Category(val title: String) {
    Social("Social"), Media("Media"), Games("Games"),
    Productivity("Productivity"), Tools("Tools"), Other("Other")
}

@Immutable
data class AppItem(
    val label: String,
    val pkg: String,
    val cls: String,
    val icon: ImageBitmap,
    val category: Category
)

@Immutable
class HaloTheme(
    val name: String,
    val accent: Color,
    val onAccent: Color,
    val surface: Color,
    val scrimTop: Color,
    val scrimBottom: Color,
    val card: Color
)

val Themes = listOf(
    HaloTheme("Ember", Color(0xFFFF7A45), Color(0xFF2B1105), Color(0xFF14100D),
        Color(0x33000000), Color(0xB3180C06), Color(0x26FFFFFF)),
    HaloTheme("Ocean", Color(0xFF4DA3FF), Color(0xFF021A33), Color(0xFF0A1118),
        Color(0x33000000), Color(0xB3061220), Color(0x26FFFFFF)),
    HaloTheme("Forest", Color(0xFF5FD38D), Color(0xFF032314), Color(0xFF0B130E),
        Color(0x33000000), Color(0xB3071409), Color(0x26FFFFFF)),
    HaloTheme("Sakura", Color(0xFFFF8FB8), Color(0xFF330A1B), Color(0xFF160D11),
        Color(0x33000000), Color(0xB3200A14), Color(0x26FFFFFF)),
    HaloTheme("Mono", Color(0xFFE6E6E6), Color(0xFF111111), Color(0xFF0C0C0C),
        Color(0x33000000), Color(0xB3000000), Color(0x22FFFFFF))
)

class LauncherPrefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("halo2", Context.MODE_PRIVATE)

    var theme by mutableIntStateOf(sp.getInt("theme", 0).coerceIn(0, Themes.lastIndex))
        private set
    var iconStyle by mutableIntStateOf(sp.getInt("iconStyle", 0))
        private set
    var iconSize by mutableFloatStateOf(sp.getFloat("iconSize", 56f))
        private set
    var labels by mutableStateOf(sp.getBoolean("labels", true))
        private set
    var haptics by mutableStateOf(sp.getBoolean("haptics", true))
        private set
    var cols by mutableIntStateOf(sp.getInt("cols", 3))
        private set
    var favs by mutableStateOf(sp.getString("favs", "")!!.split(",").filter { it.isNotEmpty() })
        private set

    fun updateTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun updateIconStyle(v: Int) { iconStyle = v; sp.edit().putInt("iconStyle", v).apply() }
    fun updateIconSize(v: Float) { iconSize = v }
    fun saveIconSize() { sp.edit().putFloat("iconSize", iconSize).apply() }
    fun updateLabels(v: Boolean) { labels = v; sp.edit().putBoolean("labels", v).apply() }
    fun updateHaptics(v: Boolean) { haptics = v; sp.edit().putBoolean("haptics", v).apply() }
    fun updateCols(v: Int) { cols = v; sp.edit().putInt("cols", v).apply() }
    fun toggleFav(pkg: String) {
        favs = if (pkg in favs) favs - pkg else (favs + pkg).takeLast(5)
        sp.edit().putString("favs", favs.joinToString(",")).apply()
    }
}

private val socialKw = listOf("whatsapp", "instagram", "facebook", "telegram", "snapchat", "twitter",
    "discord", "signal", "messenger", "reddit", "linkedin", "tiktok", "dialer", "contacts",
    "messaging", "mms", "sms", "threads", "bluesky")
private val mediaKw = listOf("spotify", "youtube", "netflix", "music", "video", "photos", "gallery",
    "camera", "player", "podcast", "prime", "hotstar", "soundcloud", "twitch")
private val prodKw = listOf("docs", "sheets", "slides", "drive", "office", "notion", "keep", "calendar",
    "gmail", "mail", "outlook", "teams", "slack", "zoom", "meet", "word", "excel", "powerpoint",
    "github", "claude")
private val toolsKw = listOf("settings", "calculator", "clock", "files", "chrome", "browser", "vending",
    "maps", "weather", "recorder", "compass", "translate", "store", "ember", "firefox")

fun categorize(pkg: String, info: ApplicationInfo?, label: String): Category {
    val cat = info?.category ?: ApplicationInfo.CATEGORY_UNDEFINED
    when (cat) {
        ApplicationInfo.CATEGORY_GAME -> return Category.Games
        ApplicationInfo.CATEGORY_SOCIAL -> return Category.Social
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO,
        ApplicationInfo.CATEGORY_IMAGE, ApplicationInfo.CATEGORY_NEWS -> return Category.Media
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> return Category.Productivity
        ApplicationInfo.CATEGORY_MAPS -> return Category.Tools
    }
    val key = (pkg + " " + label).lowercase()
    return when {
        socialKw.any { key.contains(it) } -> Category.Social
        mediaKw.any { key.contains(it) } -> Category.Media
        key.contains("game") -> Category.Games
        prodKw.any { key.contains(it) } -> Category.Productivity
        toolsKw.any { key.contains(it) } -> Category.Tools
        info != null && (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 -> Category.Tools
        else -> Category.Other
    }
}

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { ri ->
            val label = ri.loadLabel(pm).toString()
            AppItem(
                label,
                ri.activityInfo.packageName,
                ri.activityInfo.name,
                ri.loadIcon(pm).toBitmap(160, 160).asImageBitmap(),
                categorize(ri.activityInfo.packageName, ri.activityInfo.applicationInfo, label)
            )
        }
        .sortedBy { it.label.lowercase() }
}
