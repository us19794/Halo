package com.halo.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(
    apps: List<AppItem>,
    prefs: LauncherPrefs,
    theme: HaloTheme,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    Column(
        modifier
            .fillMaxSize()
            .background(theme.surface)
            .pointerInput(Unit) {}
            .statusBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹", fontSize = 34.sp, color = theme.accent) }
            Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
        }
        LazyColumn(
            modifier = Modifier.navigationBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Section("Theme", theme) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Themes.forEachIndexed { i, t ->
                            val sel = i == prefs.theme
                            val s by animateFloatAsState(if (sel) 1.08f else 1f, spring(0.55f, 500f), label = "swatch")
                            Column(
                                Modifier.graphicsLayer { scaleX = s; scaleY = s }.clickable { prefs.updateTheme(i) },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val shape = RoundedCornerShape(22.dp)
                                Box(
                                    Modifier
                                        .size(64.dp)
                                        .clip(shape)
                                        .background(Brush.linearGradient(listOf(t.surface, t.accent)))
                                        .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color(0x33FFFFFF), shape)
                                )
                                Text(t.name, color = if (sel) theme.accent else Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                }
            }
            item {
                Section("Icons", theme) {
                    Segmented(listOf("Default", "Tinted", "Clear"), prefs.iconStyle, theme) { prefs.updateIconStyle(it) }
                    Row(
                        Modifier.fillMaxWidth().padding(top = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        apps.take(5).forEach { AppIcon(it, prefs.iconSize.dp, prefs.iconStyle, theme.accent) }
                    }
                    Text("Icon size", color = Color.White, modifier = Modifier.padding(top = 16.dp))
                    Slider(
                        value = prefs.iconSize,
                        onValueChange = { prefs.updateIconSize(it) },
                        onValueChangeFinished = { prefs.saveIconSize() },
                        valueRange = 44f..72f
                    )
                    SwitchRow("Show labels", "App names under icons", prefs.labels) { prefs.updateLabels(it) }
                }
            }
            item {
                Section("App drawer", theme) {
                    Text("Icons per row in each category", color = Color.White, modifier = Modifier.padding(bottom = 8.dp))
                    Segmented(listOf("3", "4"), prefs.cols - 3, theme) { prefs.updateCols(it + 3) }
                }
            }
            item {
                Section("Feel", theme) {
                    SwitchRow("Haptics", "Vibrate on long-press", prefs.haptics) { prefs.updateHaptics(it) }
                    Text(
                        "Halo asks your display for its highest refresh rate (120 Hz) automatically.",
                        color = Color(0x99FFFFFF), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
            item {
                Section("System", theme) {
                    TextButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text("Choose default home app", color = theme.accent) }
                    Text("Halo 2.0", color = Color(0x99FFFFFF), fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp))
                }
            }
        }
    }
}

@Composable
fun Section(title: String, theme: HaloTheme, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(
            title, color = theme.accent, style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
        )
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(theme.card).padding(16.dp),
            content = content
        )
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color(0x99FFFFFF), fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, theme: HaloTheme, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Color(0x1FFFFFFF)).padding(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            val bg by animateColorAsState(if (sel) theme.accent else Color.Transparent, label = "seg")
            val fg by animateColorAsState(if (sel) theme.onAccent else Color.White, label = "segfg")
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(bg)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(label, color = fg, fontWeight = FontWeight.SemiBold) }
        }
    }
}
