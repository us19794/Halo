package com.halo.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { LauncherScreen() }
        }
    }
}

data class AppItem(val label: String, val pkg: String, val cls: String, val icon: ImageBitmap)

val Accents = listOf(
    Color(0xFFFF7A45), Color(0xFF7C9CFF), Color(0xFF6EE7B7), Color(0xFFF472B6), Color(0xFFFFFFFF)
)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0).map {
        AppItem(
            it.loadLabel(pm).toString(),
            it.activityInfo.packageName,
            it.activityInfo.name,
            it.loadIcon(pm).toBitmap(144, 144).asImageBitmap()
        )
    }.sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, a: AppItem) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(a.pkg, a.cls)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

@Composable
fun LauncherScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("halo", Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var reload by remember { mutableIntStateOf(0) }
    var drawer by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var favs by remember {
        mutableStateOf(prefs.getString("favs", "")!!.split(",").filter { it.isNotEmpty() })
    }
    var accentIdx by remember { mutableIntStateOf(prefs.getInt("accent", 0)) }
    var cols by remember { mutableIntStateOf(prefs.getInt("cols", 4)) }
    var now by remember { mutableStateOf(Date()) }
    val accent = Accents[accentIdx]

    LaunchedEffect(reload) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { reload++ }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(r) }
    }

    fun toggleFav(pkg: String) {
        favs = if (pkg in favs) favs - pkg else (favs + pkg).takeLast(5)
        prefs.edit().putString("favs", favs.joinToString(",")).apply()
    }

    BackHandler(drawer) { drawer = false }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { settings = true }) }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -120f) drawer = true },
                    onVerticalDrag = { _, d -> total += d }
                )
            }
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Spacer(Modifier.height(48.dp))
            Text(
                android.text.format.DateFormat.getTimeFormat(ctx).format(now),
                color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light
            )
            Text(
                SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
                color = accent, fontSize = 18.sp
            )
            Spacer(Modifier.weight(1f))
            Text(
                "Swipe up for apps · hold for settings",
                color = Color(0x99FFFFFF), fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                textAlign = TextAlign.Center
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0x66000000), RoundedCornerShape(32.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val dock = favs.mapNotNull { p -> apps.find { it.pkg == p } }
                if (dock.isEmpty()) {
                    Text(
                        "Long-press an app in the drawer to pin it here",
                        color = Color(0xBBFFFFFF), fontSize = 13.sp, modifier = Modifier.padding(12.dp)
                    )
                }
                dock.forEach { AppCell(it, false, true) { toggleFav(it.pkg) } }
            }
        }

        AnimatedVisibility(
            drawer,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            Drawer(apps, cols, favs, accent, ::toggleFav, { settings = true })
        }
    }

    if (settings) {
        AlertDialog(
            onDismissRequest = { settings = false },
            confirmButton = { TextButton(onClick = { settings = false }) { Text("Done") } },
            title = { Text("Settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Accent colour")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Accents.forEachIndexed { i, c ->
                            Box(
                                Modifier
                                    .size(36.dp)
                                    .background(c, CircleShape)
                                    .then(if (i == accentIdx) Modifier.border(3.dp, Color.Gray, CircleShape) else Modifier)
                                    .clickable {
                                        accentIdx = i
                                        prefs.edit().putInt("accent", i).apply()
                                    }
                            )
                        }
                    }
                    Text("Drawer columns")
                    Row {
                        listOf(4, 5, 6).forEach { n ->
                            TextButton(onClick = {
                                cols = n
                                prefs.edit().putInt("cols", n).apply()
                            }) {
                                Text(n.toString(), color = if (n == cols) accent else Color.Gray)
                            }
                        }
                    }
                    TextButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text("Default home app…") }
                }
            }
        )
    }
}

@Composable
fun Drawer(
    apps: List<AppItem>, cols: Int, favs: List<String>, accent: Color,
    onFav: (String) -> Unit, onSettings: () -> Unit
) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val shown = apps.filter { it.label.contains(query, ignoreCase = true) }
    Column(
        Modifier.fillMaxSize().background(Color(0xF0000000)).statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search apps") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { shown.firstOrNull()?.let { launchApp(ctx, it) } }),
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0x22FFFFFF), unfocusedContainerColor = Color(0x22FFFFFF),
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = accent
                ),
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onSettings) { Text("⚙", fontSize = 22.sp, color = accent) }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            modifier = Modifier.fillMaxSize().padding(top = 8.dp)
        ) {
            items(shown, key = { it.pkg + it.cls }) { app ->
                AppCell(app, true, app.pkg in favs) { onFav(app.pkg) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(app: AppItem, showLabel: Boolean, isFav: Boolean, onToggleFav: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Column(
        Modifier
            .combinedClickable(onClick = { launchApp(ctx, app) }, onLongClick = { menu = true })
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(app.icon, app.label, Modifier.size(56.dp))
        if (showLabel) {
            Text(
                app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(if (isFav) "Remove from dock" else "Add to dock") },
                onClick = { menu = false; onToggleFav() }
            )
            DropdownMenuItem(text = { Text("App info") }, onClick = {
                menu = false
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            })
            DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                menu = false
                ctx.startActivity(
                    Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            })
        }
    }
}
