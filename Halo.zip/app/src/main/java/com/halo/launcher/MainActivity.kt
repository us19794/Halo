package com.halo.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var homeTick by mutableIntStateOf(0)

    @OptIn(ExperimentalMaterial3ExpressiveApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        requestHighRefresh()
        setContent {
            val prefs = remember { LauncherPrefs(applicationContext) }
            val t = Themes[prefs.theme]
            val scheme = remember(t) {
                darkColorScheme(
                    primary = t.accent, onPrimary = t.onAccent,
                    secondary = t.accent, onSecondary = t.onAccent,
                    background = t.surface, surface = t.surface,
                    onBackground = Color.White, onSurface = Color.White,
                    surfaceVariant = t.card, primaryContainer = t.accent.copy(alpha = 0.25f)
                )
            }
            MaterialExpressiveTheme(colorScheme = scheme, motionScheme = MotionScheme.expressive()) {
                Root(prefs, t, homeTick)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        requestHighRefresh()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeTick++ // Home button pressed: close drawer / settings.
    }

    /** Ask the display for its highest refresh rate at the current resolution (120 Hz where supported). */
    @Suppress("DEPRECATION")
    private fun requestHighRefresh() {
        try {
            val d = windowManager.defaultDisplay ?: return
            val cur = d.mode
            val best = d.supportedModes
                .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
        } catch (_: Exception) {
        }
    }
}

@Composable
fun Root(prefs: LauncherPrefs, theme: HaloTheme, homeTick: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var reload by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }

    LaunchedEffect(reload) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { reload++ }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(r) }
    }
    LaunchedEffect(homeTick) { if (homeTick > 0) showSettings = false }

    val sp = animateFloatAsState(
        if (showSettings) 1f else 0f,
        spring(dampingRatio = 0.86f, stiffness = 380f),
        label = "settings"
    )
    val settingsVisible by remember { derivedStateOf { sp.value > 0.001f } }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(
            apps, prefs, theme, homeTick,
            onSettings = { showSettings = true },
            modifier = Modifier.graphicsLayer {
                val s = 1f - 0.06f * sp.value
                scaleX = s
                scaleY = s
                translationX = -size.width * 0.2f * sp.value
                alpha = 1f - 0.5f * sp.value
            }
        )
        if (settingsVisible) {
            SettingsScreen(
                apps, prefs, theme,
                onBack = { showSettings = false },
                modifier = Modifier.graphicsLayer { translationX = size.width * (1f - sp.value) }
            )
        }
    }
    BackHandler(showSettings) { showSettings = false }
}
