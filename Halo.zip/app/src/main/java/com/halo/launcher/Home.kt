package com.halo.launcher

import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalView

@Composable
fun HomeScreen(
    apps: List<AppItem>,
    prefs: LauncherPrefs,
    theme: HaloTheme,
    resetKey: Int,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    // p: 0 = home, 1 = drawer fully open. A plain state so dragging never waits on a coroutine.
    var p by remember { mutableFloatStateOf(0f) }
    var heightPx by remember { mutableFloatStateOf(1f) }
    val animJob = remember { arrayOfNulls<Job>(1) }
    val open by remember { derivedStateOf { p > 0.001f } }
    val spec = remember { spring<Float>(dampingRatio = 0.8f, stiffness = 320f) }

    fun tick() {
        if (prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    fun settle(target: Float, velocity: Float = 0f) {
        animJob[0]?.cancel()
        animJob[0] = scope.launch {
            animate(p, target, velocity, spec) { v, _ -> p = v }
        }
    }

    // Moves the drawer by a drag of dy pixels (positive = finger moving down); returns pixels consumed.
    fun pull(dy: Float): Float {
        val k = heightPx * 0.75f
        val cur = p
        val next = (cur - dy / k).coerceIn(0f, 1f)
        if (next != cur) {
            animJob[0]?.cancel()
            p = next
        }
        return (cur - next) * k
    }

    fun release(vy: Float) {
        val close = vy > 700f || (p < 0.5f && vy > -700f)
        settle(if (close) 0f else 1f, -vy / (heightPx * 0.75f))
    }

    LaunchedEffect(resetKey) { if (resetKey > 0) settle(0f) }
    BackHandler(open) { settle(0f) }

    val dragState = rememberDraggableState { d -> pull(d) }

    Box(
        modifier
            .fillMaxSize()
            .onSizeChanged { heightPx = it.height.toFloat() }
            .draggable(
                state = dragState,
                orientation = Orientation.Vertical,
                onDragStopped = { v -> release(v) }
            )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(theme.scrimTop, theme.scrimBottom)))
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { tick(); onSettings() })
                }
        )

        HomeContent(
            apps, prefs, theme,
            Modifier.graphicsLayer {
                val s = 1f - 0.1f * p
                scaleX = s
                scaleY = s
                alpha = (1f - p * 1.4f).coerceIn(0f, 1f)
            }
        )

        if (open) {
            val conn = remember {
                object : NestedScrollConnection {
                    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                        if (available.y < 0f && p < 1f) return Offset(0f, pull(available.y))
                        return Offset.Zero
                    }

                    override fun onPostScroll(
                        consumed: Offset, available: Offset, source: NestedScrollSource
                    ): Offset {
                        if (available.y > 0f && source == NestedScrollSource.UserInput) {
                            return Offset(0f, pull(available.y))
                        }
                        return Offset.Zero
                    }

                    override suspend fun onPreFling(available: Velocity): Velocity {
                        if (p < 0.999f) { release(available.y); return available }
                        return Velocity.Zero
                    }

                    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                        if (available.y > 700f) { release(available.y); return available }
                        return Velocity.Zero
                    }
                }
            }
            Drawer(
                apps, prefs, theme, onSettings,
                Modifier
                    .graphicsLayer {
                        val q = p
                        translationY = (1f - q) * size.height * 0.3f
                        alpha = q.coerceIn(0f, 1f)
                        val s = 0.92f + 0.08f * q
                        scaleX = s
                        scaleY = s
                    }
                    .nestedScroll(conn)
            )
        }
    }
}

@Composable
fun HomeContent(apps: List<AppItem>, prefs: LauncherPrefs, theme: HaloTheme, modifier: Modifier) {
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }
    val enter by animateFloatAsState(
        if (entered) 1f else 0f, spring(dampingRatio = 0.75f, stiffness = 200f), label = "enter"
    )
    Column(
        modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Spacer(Modifier.height(40.dp))
        Column(Modifier.graphicsLayer { alpha = enter; translationY = (1f - enter) * 60f }) {
            Clock(theme)
        }
        Spacer(Modifier.weight(1f))
        Text(
            "Swipe up for apps · hold for settings",
            color = Color(0x99FFFFFF), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            textAlign = TextAlign.Center
        )
        Dock(apps, prefs, theme, Modifier.graphicsLayer { alpha = enter; translationY = (1f - enter) * 120f })
    }
}

@Composable
fun Clock(theme: HaloTheme) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - now % 60_000L + 50L)
        }
    }
    val is24 = DateFormat.is24HourFormat(ctx)
    val time = remember(now, is24) {
        SimpleDateFormat(if (is24) "H:mm" else "h:mm", Locale.getDefault()).format(Date(now))
    }
    val date = remember(now) {
        SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now))
    }
    // First digit red, every other digit white.
    val styled = remember(time) {
        buildAnnotatedString {
            time.forEachIndexed { i, ch ->
                withStyle(SpanStyle(color = if (i == 0) Color(0xFFFF3B30) else Color.White)) { append(ch) }
            }
        }
    }
    Text(styled, fontSize = 84.sp, fontWeight = FontWeight.SemiBold)
    Text(date, color = theme.accent, fontSize = 18.sp, fontWeight = FontWeight.Medium)
}

@Composable
fun Dock(apps: List<AppItem>, prefs: LauncherPrefs, theme: HaloTheme, modifier: Modifier) {
    val dock = remember(apps, prefs.favs) {
        prefs.favs.mapNotNull { f -> apps.firstOrNull { it.pkg == f } }
    }
    val shape = RoundedCornerShape(36.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(theme.card)
            .border(1.dp, Color(0x22FFFFFF), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dock.isEmpty()) {
            Text(
                "Long-press an app in the drawer to pin it here",
                color = Color(0xBBFFFFFF), fontSize = 13.sp, modifier = Modifier.padding(14.dp)
            )
        }
        dock.forEach { AppCell(it, prefs, theme, false) }
    }
}

@Composable
fun Drawer(
    apps: List<AppItem>,
    prefs: LauncherPrefs,
    theme: HaloTheme,
    onSettings: () -> Unit,
    modifier: Modifier
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    var query by remember { mutableStateOf("") }
    val groups = remember(apps) {
        Category.entries.map { c -> c to apps.filter { it.category == c } }.filter { it.second.isNotEmpty() }
    }
    val results = remember(apps, query) {
        if (query.isBlank()) emptyList() else apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Column(
        modifier
            .fillMaxSize()
            .background(theme.surface.copy(alpha = 0.94f))
            .pointerInput(Unit) {}
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search apps") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    results.firstOrNull()?.let { launchApp(ctx, view, it, null) }
                }),
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = theme.card,
                    unfocusedContainerColor = theme.card,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = theme.accent
                ),
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onSettings) { Text("⚙", fontSize = 24.sp, color = theme.accent) }
        }

        if (query.isNotBlank()) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                items(results, key = { it.pkg + it.cls }) { app ->
                    AppCell(app, prefs, theme, prefs.labels, Modifier.animateItem())
                }
            }
        } else {
            val pager = rememberPagerState(pageCount = { groups.size })
            val scope = rememberCoroutineScope()
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                groups.forEachIndexed { i, (cat, list) ->
                    val sel = pager.currentPage == i
                    val bg by animateColorAsState(if (sel) theme.accent else theme.card, label = "tab")
                    val fg by animateColorAsState(if (sel) theme.onAccent else Color.White, label = "tabfg")
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(bg)
                            .clickable { scope.launch { pager.animateScrollToPage(i) } }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text("${cat.title} · ${list.size}", color = fg, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val pageW = maxWidth - 56.dp
                HorizontalPager(
                    state = pager,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 24.dp),
                    pageSize = PageSize.Fixed(pageW),
                    pageSpacing = 12.dp
                ) { page ->
                    val group = groups.getOrNull(page)
                    if (group != null) {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .padding(vertical = 8.dp)
                                .graphicsLayer {
                                    val off = abs(pager.currentPage - page + pager.currentPageOffsetFraction)
                                        .coerceIn(0f, 1f)
                                    val s = 1f - 0.07f * off
                                    scaleX = s
                                    scaleY = s
                                    alpha = 1f - 0.4f * off
                                }
                                .clip(RoundedCornerShape(32.dp))
                                .background(theme.card)
                                .padding(12.dp)
                        ) {
                            Text(
                                group.first.title,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = theme.accent,
                                modifier = Modifier.padding(8.dp)
                            )
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(prefs.cols),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(group.second, key = { it.pkg + it.cls }) { app ->
                                    AppCell(app, prefs, theme, prefs.labels, Modifier.animateItem())
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
