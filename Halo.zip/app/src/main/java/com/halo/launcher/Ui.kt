package com.halo.launcher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.View
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun iconFilter(style: Int, accent: Color): ColorFilter? = when (style) {
    1 -> {
        val g = 1.35f
        val r = accent.red
        val gr = accent.green
        val b = accent.blue
        ColorFilter.colorMatrix(
            ColorMatrix(
                floatArrayOf(
                    0.299f * g * r, 0.587f * g * r, 0.114f * g * r, 0f, 14f * r,
                    0.299f * g * gr, 0.587f * g * gr, 0.114f * g * gr, 0f, 14f * gr,
                    0.299f * g * b, 0.587f * g * b, 0.114f * g * b, 0f, 14f * b,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    2 -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                0.45f, 0.88f, 0.17f, 0f, 38f,
                0.45f, 0.88f, 0.17f, 0f, 38f,
                0.45f, 0.88f, 0.17f, 0f, 38f,
                0f, 0f, 0f, 0.9f, 0f
            )
        )
    )
    else -> null
}

@Composable
fun AppIcon(app: AppItem, size: Dp, style: Int, accent: Color) {
    val filter = remember(style, accent) { iconFilter(style, accent) }
    val shape = RoundedCornerShape(size * 0.27f)
    val mod = if (style == 2) {
        Modifier.size(size).clip(shape).background(Color(0x40FFFFFF)).border(1.dp, Color(0x55FFFFFF), shape)
    } else Modifier.size(size)
    Image(bitmap = app.icon, contentDescription = null, modifier = mod, colorFilter = filter)
}

fun launchApp(ctx: Context, view: View, a: AppItem, r: Rect?) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(a.pkg, a.cls)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    val opts = r?.let {
        ActivityOptions.makeScaleUpAnimation(
            view, it.left.toInt(), it.top.toInt(), it.width.toInt(), it.height.toInt()
        ).toBundle()
    }
    try { ctx.startActivity(i, opts) } catch (_: Exception) {}
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    app: AppItem,
    prefs: LauncherPrefs,
    theme: HaloTheme,
    showLabel: Boolean,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.82f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 700f),
        label = "press"
    )
    val bounds = remember { arrayOfNulls<Rect>(1) }
    var menu by remember { mutableStateOf(false) }
    val isFav = app.pkg in prefs.favs

    Column(
        modifier
            .onGloballyPositioned { bounds[0] = it.boundsInWindow() }
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = { launchApp(ctx, view, app, bounds[0]) },
                onLongClick = {
                    if (prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    menu = true
                }
            )
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app, prefs.iconSize.dp, prefs.iconStyle, theme.accent)
        if (showLabel) {
            Text(
                app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp).widthIn(max = prefs.iconSize.dp + 20.dp)
            )
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(if (isFav) "Unpin from dock" else "Pin to dock") },
                onClick = { menu = false; prefs.toggleFav(app.pkg) }
            )
            DropdownMenuItem(text = { Text("App info") }, onClick = {
                menu = false
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            })
            DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                menu = false
                ctx.startActivity(
                    Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            })
        }
    }
}
